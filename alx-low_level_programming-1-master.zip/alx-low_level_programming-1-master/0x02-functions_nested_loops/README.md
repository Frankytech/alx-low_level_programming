Functions and Nested Loops programs
