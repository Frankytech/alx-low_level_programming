Low Level Language Programming with C
If or else statment task
